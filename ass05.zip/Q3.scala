object Q3 {
  def sum(n: Int): Int = {
    if(n>1)  n + sum(n - 1)
    else n
  }

  def main(args: Array[String]): Unit = {
    printf("Enter the number:")
    val n = scala.io.StdIn.readInt()
    val s = sum(n)
    printf("sum is = %d", s)


  }
}