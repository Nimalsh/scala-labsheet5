object Q2 {
  def gcd(a: Int, b: Int): Int = b match {
    case 0 => a
    case x if x > a => gcd(x, a)
    case x if x <= a => gcd(x, a % x)
  }

  def prime(p:Int,n:Int=2):Boolean= n match {
    case x if (x == p) => true
    case x if gcd(p, x) > 1 => false
    case x => prime(p, x + 1)

  }

  def primeSeq(n:Int):Unit={
    if (prime(n)){
      print(n)
      println()
    }
    if (n>0) primeSeq(n-1)
  }

  def main(args: Array[String]): Unit = {
    printf("Enter the number:");
    val n = scala.io.StdIn.readInt()
    primeSeq(n);
  }

}