object Main {
  def sumEvenNumbers(n: Int): Int = {
    if (n <= 1) {
      0
    } else if (n % 2 == 0) {
      n + sumEvenNumbers(n - 2)
    } else {
      sumEvenNumbers(n - 1)
    }
  }

  def main(args: Array[String]): Unit = {
    val n = 4
    val result = sumEvenNumbers(n)
    println(s"Sum of even numbers less than $n is $result")
  }

}