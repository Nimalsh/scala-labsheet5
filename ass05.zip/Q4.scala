object Q4 {
  def isEven(n: Int): Boolean = n match {
    case 0 => true
    case _ => isOdd(n - 1)
  }

  def isOdd(n: Int): Boolean = !(isEven(n))

  def main(args: Array[String]): Unit = {
    printf("Enter the number:")
    val n = scala.io.StdIn.readInt()
    if (isEven(n)) println("This is a Even number");
    else println("This is a Odd number");
  }
}
