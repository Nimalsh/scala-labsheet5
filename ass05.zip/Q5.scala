object Q5 {

}
